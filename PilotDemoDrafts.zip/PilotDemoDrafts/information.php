<!DOCTYPE html>
<html lang="en">

<?php
include('connection.php');
?>

<head>
  <title>Course Information</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="favicon.png" type="image/png" sizes="16x16">
  <link href='https://fonts.googleapis.com/css?family=Proxima+Nova:400,700' rel='stylesheet'>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>

<style>
h4 {
  margin-bottom:5px;
}
</style>

<body style="margin-bottom:35px;">

  <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container" style="height:80px;">
      <div class="navbar-header">
        <a class="navbar-brand" href="index.html"><img src="Logo.png" style="width:325px;"></a>
      </div>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.html" style="color:#004684;"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
      </ul>
    </div>
    <div class="container-fluid" style="background:#004684;">
      <div class="container">
        <div class="navbar-header welcome-message">
          Welcome, Student!
        </div>
        <ul class="nav navbar-nav">
          <li><a href="dashboard.html">Dashboard</a></li>
          <li><a href="profile.php">Student Profile</a></li>
          <li class="active"><a href="search.html">Course Search</a></li>
          <li><a href="registration.html">Registration</a></li>
          <li><a href="financial.php">Financial Aid</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="container">

    <div class="row">
      <div class="col-sm-3">
        <h2>CST 140 001</h2>
      </div>
      <div class="col-sm-8">
        <h2>Introduction to Computer Programming</h2>
      </div>
      <div class="col-sm-1">
        <h2>21048</h2>
      </div>
    </div>

    <p style="margin-bottom:20px;">This course gives an introduction to computer programming. Topics include structured program development and the use of a high level programming language to develop software applications.</p>

    <div class="row">
      <div class="col-sm-2">
        <h4>Credit Hours</h4>
        <p>3.0</p>
      </div>
      <div class="col-sm-2">
        <h4>Environment</h4>
        <p>On-Campus</p>
      </div>
      <div class="col-sm-2">
        <h4>Prerequisites</h4>
        <p>None</p>
      </div>
      <div class="col-sm-2">
        <h4>Corequisites</h4>
        <p>None</p>
      </div>
      <div class="col-sm-2">
        <h4>Seat Capacity</h4>
        <p>45</p>
      </div>
      <div class="col-sm-2">
        <h4>Seats Available</h4>
        <p>0</p>
      </div>
    </div>

    <div class="row" style="margin-top:25px;">
      <div class="col-sm-3" style="border-right:1px solid;">
        <h4>Date Range</h4>
        <p style="margin-bottom:15px;">January 14, 2019 - May 10, 2019</p>
        <h4>Meeting Days</h4>
        <p style="margin-bottom:15px;">Tuesday, Thursday</p>
        <h4>Meeting Times</h4>
        <p style="margin-bottom:15px;">11:00am - 12:15pm</p>
        <h4>Meeting Location</h4>
        <p>Smith Hall 4001</p>
      </div>
      <div class="col-sm-3" style="border-right:1px solid;">
        <h4>Instructor</h4>
        <p style="margin-bottom:15px;">Angela Lemons</p>
        <h4>Instructor Email</h4>
        <p style="margin-bottom:15px;">alemons@ncat.edu</p>
        <h4>Office Phone</h4>
        <p style="margin-bottom:15px;">N/A</p>
        <h4>Office Location</h4>
        <p>N/A</p>
      </div>
      <div class="col-sm-2">
        <img src="9780134543666.jpg" style="height:220px; margin-top:10px;">
      </div>
      <div class="col-sm-4">
        <h4 style="margin-bottom:15px;">Required Textbook</h4>
        <strong>Title </strong>Starting Out with Python (with Access Code)<br>
        <strong>Author </strong> Tony Gaddis<br>
        <strong>Edition </strong> 4th<br>
        <strong>Release Year </strong> 2018<br>
        <strong>Publisher </strong> Pearson<br>
        <strong>ISBN </strong> 9780134543666<br>

        <a href="https://ncat.bncollege.com/webapp/wcs/stores/servlet/BNCB_TextbookDetailView?catalogId=10001&item=N&langId=-1&productId=600008036650&storeId=74236" target="_blank">
          <div class="purchase-textbook">Purchase Textbook</div>
        </a>
      </div>
    </div>

  </div>

</body>

<?php
$conn->close();
?>

</html>
