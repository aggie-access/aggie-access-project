<!DOCTYPE html>
<html lang="en">

<?php
include('connection.php');
?>

<head>
  <title>Registration Confirmation</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="favicon.png" type="image/png" sizes="16x16">
  <link href='https://fonts.googleapis.com/css?family=Proxima+Nova:400,700' rel='stylesheet'>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>

<body style="margin-bottom:35px;">

  <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container" style="height:80px;">
      <div class="navbar-header">
        <a class="navbar-brand" href="index.html"><img src="Logo.png" style="width:325px;"></a>
      </div>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.html" style="color:#004684;"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
      </ul>
    </div>
    <div class="container-fluid" style="background:#004684;">
      <div class="container">
        <div class="navbar-header welcome-message">
          Welcome, Student!
        </div>
        <ul class="nav navbar-nav">
          <li><a href="dashboard.html">Dashboard</a></li>
          <li><a href="profile.php">Student Profile</a></li>
          <li><a href="search.html">Course Search</a></li>
          <li class="active"><a href="registration.html">Registration</a></li>
          <li><a href="financial.php">Financial Aid</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="container">

    <h1>Registration Confirmation</h1>
    <p style="margin-bottom:20px;">You have been successfully registered for the upcoming semester.</p>

    <div class="row" style="margin-bottom:15px;">
      <div class="col-sm-3">
        <h3>Spring 2019</h3>
      </div>
      <div class="col-sm-6">
        <h3 style="text-align:center;">January 14, 2019 - May 10, 2019</h3>
      </div>
      <div class="col-sm-3">
        <h3 style="text-align:right;">15 Credits</h3>
      </div>
    </div>

    <table class="table table-striped">
      <thead>
        <tr>
          <th>CRN</th>
          <th>Course</th>
          <th>Section</th>
          <th>Title</th>
          <th>Credits</th>
          <th>Instructor</th>
          <th>Type</th>
          <th>Days</th>
          <th>Times</th>
          <th>Location</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>21409</td>
          <td>CST 112</td>
          <td>002</td>
          <td>Electric Circuits I</td>
          <td>3.0</td>
          <td>William Bowen</td>
          <td>Campus</td>
          <td>TR</td>
          <td>9:00am - 10:15am</td>
          <td>Smith 4001</td>
        </tr>
        <tr>
          <td>22466</td>
          <td>CST 122</td>
          <td>003</td>
          <td>Electric Circuits I Lab</td>
          <td>1.0</td>
          <td>William Bowen</td>
          <td>Campus</td>
          <td>R</td>
          <td>1:00pm - 3:50pm</td>
          <td>Smith 4008</td>
        </tr>
        <tr>
          <td>21903</td>
          <td>CST 140</td>
          <td>05A</td>
          <td>Introduction to Computer Programming</td>
          <td>3.0</td>
          <td>Anthony Joyner</td>
          <td>Online</td>
          <td>N/A</td>
          <td>N/A</td>
          <td>Blackboard</td>
        </tr>
        <tr>
          <td>21939</td>
          <td>CST 150</td>
          <td>001</td>
          <td>Introduction to Computer Programming Lab</td>
          <td>1.0</td>
          <td>Angela Lemons</td>
          <td>Campus</td>
          <td>M</td>
          <td>2:00pm - 4:50pm</td>
          <td>Smith 4009</td>
        </tr>
        <tr>
          <td>20111</td>
          <td>ENGL 101</td>
          <td>007</td>
          <td>Ideas and Their Expressions II</td>
          <td>3.0</td>
          <td>Moussa Issifou</td>
          <td>Campus</td>
          <td>TR</td>
          <td>4:00pm - 5:15pm</td>
          <td>GCB A202</td>
        </tr>
        <tr>
          <td>22915</td>
          <td>MATH 131</td>
          <td>05A</td>
          <td>Calculus I</td>
          <td>4.0</td>
          <td>Zachary Denton</td>
          <td>Online</td>
          <td>N/A</td>
          <td>N/A</td>
          <td>Blackboard</td>
        </tr>
      </tbody>
    </table>

  </div>

</body>

<?php
$conn->close();
?>

</html>
