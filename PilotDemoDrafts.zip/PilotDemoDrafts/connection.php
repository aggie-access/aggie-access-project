<?php
$conn = mysqli_connect("localhost:8889", "root", "root", "SeniorProject");
if ($conn-> connect_error) {
  die("Connection Failed:". $conn-> connect_error);
}
?>
