
<?php
$host="localhost";
$port="	8889";
$user="Aggies";
$password="aggies";
$dbname="mysql";
$socket="/Applications/MAMP/tmp/mysql/mysql.sock";

$conn = mysqli_connect($host, $port, $user, $password, $dbname)
	or die ('Could not connect to the database server' . mysqli_connect_error());

$conn->close();


?>