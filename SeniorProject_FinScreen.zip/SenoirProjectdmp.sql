-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Mar 23, 2019 at 01:27 PM
-- Server version: 5.7.25
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `SeniorProject`
--

-- --------------------------------------------------------

--
-- Table structure for table `Courses`
--

CREATE TABLE `Courses` (
  `idCourses` int(11) NOT NULL,
  `Course_Number` varchar(45) NOT NULL,
  `Course_Name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Course_Term`
--

CREATE TABLE `Course_Term` (
  `idCourse_Term` int(11) NOT NULL,
  `Student_Id` varchar(45) NOT NULL,
  `Term` varchar(45) NOT NULL,
  `Section` varchar(45) NOT NULL,
  `Professor_ID` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Department`
--

CREATE TABLE `Department` (
  `idDepartment` int(11) NOT NULL DEFAULT '100001',
  `Dept_Name` varchar(45) NOT NULL,
  `Professor_Id` varchar(45) DEFAULT NULL,
  `Course_Number` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `fin_aid`
--

CREATE TABLE `fin_aid` (
  `idFin_Aid` int(11) NOT NULL,
  `Student_Id` varchar(45) NOT NULL,
  `Award` varchar(45) DEFAULT NULL,
  `Award_amt` int(11) DEFAULT NULL,
  `Term` varchar(45) DEFAULT NULL,
  `Status` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fin_aid`
--

INSERT INTO `fin_aid` (`idFin_Aid`, `Student_Id`, `Award`, `Award_amt`, `Term`, `Status`) VALUES
(19857, '950354656', 'Federal Pell Grant', 500, 'Spring 2019', 'Accepted'),
(19843, '950354656', 'Campus Based Tuition', 1000, 'Spring 2019', 'Accepted'),
(18723, '950354656', 'UNC Need Based Grant', 2000, 'Spring 2019', 'Accepted'),
(1982343, '950354656', 'Federal Pell Grant', 250, 'Fall 2019', 'Accepted'),
(192857, '950354656', 'Campus Based Tuition', 1500, 'Fall 2019', 'Accepted'),
(31829, '950354656', 'UNC Need Based Grant', 2250, 'Fall 2019', 'Accepted'),
(32324, '950354656', 'Federal Pell Grant', 500, 'Spring 2020', 'Accepted'),
(98078, '950354656', 'Federal Pell Grant', 750, 'Fall 2018', 'Accepted'),
(67549, '950354656', 'Campus Based Tuition', 1250, 'Spring 2020', 'Accepted'),
(37465, '950354656', 'UNC Need Based Grant', 2250, 'Spring 2020', 'Accepted'),
(87321, '950354656', 'Campus Based Tuition', 1500, 'Fall 2018', 'Accepted'),
(83945, '950354656', 'UNC Need Based Grant', 2500, 'Fall 2018', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `Grade`
--

CREATE TABLE `Grade` (
  `idGrade` int(11) NOT NULL,
  `Student_Id` varchar(45) DEFAULT NULL,
  `Course_Number` varchar(45) DEFAULT NULL,
  `Term` varchar(45) DEFAULT NULL,
  `Section` varchar(45) DEFAULT NULL,
  `Professor_Id` varchar(45) DEFAULT NULL,
  `Grade` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Professor`
--

CREATE TABLE `Professor` (
  `idProfessor` int(11) NOT NULL,
  `Professor_Id` varchar(45) DEFAULT NULL,
  `Professor_FN` varchar(45) DEFAULT NULL,
  `Professor_LN` varchar(45) DEFAULT NULL,
  `Department` varchar(45) DEFAULT NULL,
  `Office` varchar(45) DEFAULT NULL,
  `Ofc_Phone` varchar(45) DEFAULT NULL,
  `Professor_Email` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Registration`
--

CREATE TABLE `Registration` (
  `idRegistration` int(11) NOT NULL,
  `Student_Id` varchar(45) DEFAULT NULL,
  `Course_Number` varchar(45) DEFAULT NULL,
  `Term` varchar(45) DEFAULT NULL,
  `Section` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Schedule`
--

CREATE TABLE `Schedule` (
  `idSchedule` int(11) NOT NULL,
  `Course_Number` varchar(45) DEFAULT NULL,
  `Term` varchar(45) DEFAULT NULL,
  `Section` varchar(45) DEFAULT NULL,
  `Days` varchar(45) DEFAULT NULL,
  `Time` varchar(45) DEFAULT NULL,
  `Location` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Student`
--

CREATE TABLE `Student` (
  `idStudent` int(11) NOT NULL,
  `Student_Id` varchar(45) DEFAULT NULL,
  `Student_FN` varchar(45) DEFAULT NULL,
  `Student_LN` varchar(45) DEFAULT NULL,
  `Estimated_Grad` varchar(45) DEFAULT NULL,
  `Student_Email` varchar(45) DEFAULT NULL,
  `Declared_Major` varchar(45) DEFAULT NULL,
  `Student_Entrance_Date` varchar(45) DEFAULT NULL,
  `Student_Address` varchar(45) DEFAULT NULL,
  `Marital_Status` varchar(45) DEFAULT NULL,
  `Active_Student` varchar(45) DEFAULT NULL,
  `PIN` varchar(45) DEFAULT NULL,
  `Student_PhoNum` varchar(45) DEFAULT NULL,
  `DOB` varchar(45) DEFAULT NULL,
  `Holds` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Student`
--

INSERT INTO `Student` (`idStudent`, `Student_Id`, `Student_FN`, `Student_LN`, `Estimated_Grad`, `Student_Email`, `Declared_Major`, `Student_Entrance_Date`, `Student_Address`, `Marital_Status`, `Active_Student`, `PIN`, `Student_PhoNum`, `DOB`, `Holds`) VALUES
(100001, '950354656', 'Tonya', 'McClendon', NULL, 'tkmcclendon@aggies.ncat.edu', 'Computer Science', NULL, NULL, 'Married', 'Active', '6336', NULL, NULL, 'No Holds');

-- --------------------------------------------------------

--
-- Table structure for table `Terms`
--

CREATE TABLE `Terms` (
  `idTerms` int(11) NOT NULL,
  `Term` varchar(45) DEFAULT NULL,
  `BegDates` varchar(45) DEFAULT NULL,
  `EndDates` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Courses`
--
ALTER TABLE `Courses`
  ADD PRIMARY KEY (`Course_Number`);

--
-- Indexes for table `Course_Term`
--
ALTER TABLE `Course_Term`
  ADD PRIMARY KEY (`Student_Id`);

--
-- Indexes for table `Department`
--
ALTER TABLE `Department`
  ADD PRIMARY KEY (`idDepartment`);

--
-- Indexes for table `Grade`
--
ALTER TABLE `Grade`
  ADD PRIMARY KEY (`idGrade`);

--
-- Indexes for table `Professor`
--
ALTER TABLE `Professor`
  ADD PRIMARY KEY (`idProfessor`);

--
-- Indexes for table `Registration`
--
ALTER TABLE `Registration`
  ADD PRIMARY KEY (`idRegistration`);

--
-- Indexes for table `Schedule`
--
ALTER TABLE `Schedule`
  ADD PRIMARY KEY (`idSchedule`);

--
-- Indexes for table `Student`
--
ALTER TABLE `Student`
  ADD PRIMARY KEY (`idStudent`);

--
-- Indexes for table `Terms`
--
ALTER TABLE `Terms`
  ADD PRIMARY KEY (`idTerms`);
